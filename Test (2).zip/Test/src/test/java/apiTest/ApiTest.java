package apiTest;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import java.io.File;
import java.io.FileNotFoundException;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.JSONArray;

import java.io.FileReader;

public class ApiTest {

	@Test(priority=1)
	public void uploadAnImage(){
		File myfile=new File(".\\src\\test\\resources\\uploadFIle\\AAAAApi.png");
		String uri="https://petstore.swagger.io/v2/pet";
		
		
		given()
		 .multiPart("file",myfile)
		 //.multiPart("file",myfile1)
		.contentType("multipart/form-data")
		 .pathParam("petId","4075")
		 .formParam("additionalMetadata", "testrs")
		 
		 
		.when()
		 .post(uri+"/{petId}/uploadImage")
		.then()
		 .statusCode(200)
		 .header("Content-Type","application/json")
		 .body("type", equalTo("unknown"))
		 .body("message",containsString("testrs"))
		 .body("message",containsString("AAAAApi.png"))
		 .log().all();

	}

	@Test(priority=2)
	public void addNewPetTOStore1() throws FileNotFoundException{
		
		File file = new File(".\\src\\test\\resources\\jsonFile\\pet.json");
		FileReader fr= new FileReader(file);
		JSONTokener jt=new JSONTokener(fr);
		JSONObject data=new JSONObject(jt);
		
		given()
		 .contentType("application/json")
		 .body(data.toString())
		.when()
		 .post("https://petstore.swagger.io/v2/pet")
		.then()
		 .statusCode(200)
		 .body("status",equalTo("available"))
		 .body("id",equalTo(123))
		 .body("category.id",equalTo(124))
		 .body("category.name",equalTo("rvtest"))
		 .body("name",equalTo("doggie"))
		 .body("photoUrls[0]",equalTo("RsTest"))
		 .body("tags[0].id",equalTo(125))
		 .body("tags[0].name",equalTo("TestShivi"))
		 .header("Content-Type","application/json")
		 .log().all();
	}
	
	@Test(priority=3)
	public void UpdateAnExistingPet() throws FileNotFoundException{
		
		File file = new File(".\\src\\test\\resources\\jsonFile\\updatePet.json");
		FileReader fr= new FileReader(file);
		JSONTokener jt=new JSONTokener(fr);
		JSONObject data=new JSONObject(jt);
		
		given()
		 .contentType("application/json")
		 .body(data.toString())
		.when()
		 .put("https://petstore.swagger.io/v2/pet")
		.then()
		 .statusCode(200)
		 .body("status",equalTo("available"))
		 .body("id",equalTo(123))
		 .body("category.id",equalTo(124))
		 .body("category.name",equalTo("Ttest"))
		 .body("name",equalTo("doggie"))
		 .body("photoUrls[0]",equalTo("RsShiviTest"))
		 .body("tags[0].id",equalTo(125))
		 .body("tags[0].name",equalTo("Tes1tShivi"))
		 .header("Content-Type","application/json")
		 .log().all();
	}
	@Test(priority=4)
	public void findPetsByStatus(){
		
				given()
		          .contentType("application/json")
		          .pathParam("myPath", "findByStatus")
		          .queryParam("status", "available")
		          
				.when()
				 .get("https://petstore.swagger.io/v2/pet/"+"{myPath}")
				.then()
				.statusCode(200)
				.body("[0].status", equalTo("available"))
				.body("[0].category.name", equalTo("string"))
				.header("Content-Type","application/json")
				.log().all();
	
				
		
		
	}
	
	
	@Test(priority=5)
	public void findPetById(){
		
		String uri="https://petstore.swagger.io/v2";
		
		Response res= given()
		 .contentType("application/json")
		 .pathParam("petId","4075")
		 
		 
		.when()
		 .get(uri+"/{petId}");
		 Assert.assertEquals(res.getStatusCode(),200);
		Assert.assertEquals(res.header("Content-Type"),"application/json");
		Assert.assertEquals(res.jsonPath().getInt("id"),4075);
		Assert.assertEquals(res.jsonPath().get("category.name"),"RvTest");
		Assert.assertEquals(res.jsonPath().get("status"),"available");
		
			
	}
	@Test(priority=6)
	public void UpdatePetInTheStoreInformOfData(){
		String uri="https://petstore.swagger.io/v2/pet";
		JSONObject data=new JSONObject();
		
		data.put("name","MyPet");
		data.put("status","available");
		given()
			.contentType("application/json")
			.pathParam("petId",1)
			.body(data.toString())
		.when()
			.post(uri+"/{petId}")
			
		.then()
				
				  .statusCode(200) 
				  .body("name",equalTo("MyPet"))
				  .body("status",equalTo("available"))
				  .header("Content-Type","application/json")
				 
		    .log().all();
		
	}
	@Test(priority=7)
	public void deletePet(){
		String uri="https://petstore.swagger.io/v2/pet";
		given()
			.header("api_key","ajkadjkj")
			.pathParam("petId","4075")
		.when()
			.delete(uri+"/{petId}")
		.then()
			.statusCode(200);
			
			
		
	}
	@Test(priority=8)
	public void returnPetInventoryByStatus(){
		String uri="https://petstore.swagger.io/v2/store/inventory";
		given()
			
		.when()
			.get(uri)
		.then()
			.statusCode(200);
			
			
		
	}
	
	@Test(priority=9)
		public void OrderPlacedForPurchasingThePet() throws FileNotFoundException{
			
			File file = new File(".\\src\\test\\resources\\jsonFile\\orderPlaced.json");
			FileReader fr= new FileReader(file);
			JSONTokener jt=new JSONTokener(fr);
			JSONObject data=new JSONObject(jt);
			
			given()
			 .contentType("application/json")
			 .body(data.toString())
			.when()
			 .post("https://petstore.swagger.io/v2/store/order")
			.then()
			 .statusCode(200)
			 .body("id",equalTo(4078))
			 .body("petId",equalTo(4079))
			 .body("quantity",equalTo(10))
			 .body("status",equalTo("placed"))
			 .body("complete",equalTo(true))
			 .header("Content-Type","application/json")
			 .log().all();
		}
		
	@Test(priority=10)
	public void findPurchaseOrderById(){
		String uri="https://petstore.swagger.io/v2/store/order/";
		given()
		.pathParam("order", 9)
			
		.when()
			.get(uri+"{order}")
		.then()
			.statusCode(200)
			.body("id", equalTo(9))
			.body("petId", equalTo(9))
			.body("quantity", equalTo(7))
			.body("status", equalTo("placed"))
			.body("complete", equalTo(true))
			.log().all();
			
			
		
	}
	
	@Test(priority=11)
	public void deletePurchaseByOrderId(){
		String uri="https://petstore.swagger.io/v2/pet";
		given()
			
			.pathParam("orderId","4075")
		.when()
			.delete(uri+"/{orderId}")
		.then()
			.statusCode(200);
			
			
		
	}
	
			@Test(priority=12)
			public void createListOfUsersWithGivenInputArray() throws FileNotFoundException{
				
				File file = new File(".\\src\\test\\resources\\jsonFile\\CreateUserList.json");
				FileReader fr= new FileReader(file);
				JSONTokener jt=new JSONTokener(fr);
				JSONArray  data=new JSONArray (jt);
				
				given()
				 .contentType("application/json")
				 .body(data.toString())
				.when()
				 .post("https://petstore.swagger.io/v2/user/createWithList")
				.then()
				 .statusCode(200)
				 .body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",equalTo("ok"))
				 .header("Content-Type","application/json")
				 .log().all();
			}
			
			@Test(priority=13)
			public void getUserByUserName(){
				String uri="https://petstore.swagger.io/v2/user/";
				given()
				.pathParam("username", "string")
					
				.when()
					.get(uri+"{username}")
				.then()
					.statusCode(200)
					.body("username", equalTo("string"))
					.body("firstName", equalTo("string"))
					.body("lastName", equalTo("string"))
					.body("email", equalTo("string"))
					.body("password", equalTo("string"))
					.log().all();
					
					
				
			}
			
			@Test(priority=14)
			public void UpdateUser() throws FileNotFoundException{
				
				File file = new File(".\\src\\test\\resources\\jsonFile\\updateUserput.json");
				FileReader fr= new FileReader(file);
				JSONTokener jt=new JSONTokener(fr);
				JSONObject  data=new JSONObject (jt);
				
				given()
				 .contentType("application/json")
				 .pathParam("username", "string")
				 .body(data.toString())
				.when()
				 .put("https://petstore.swagger.io/v2/user/"+"{username}")
				.then()
				 .statusCode(200)
				 .body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",equalTo("112"))
				 .header("Content-Type","application/json")
				 .log().all();
			}
			@Test(priority=15)
			public void loginUser(){
				String uri="https://petstore.swagger.io/v2/user";
				given()
					
				.pathParam("userlogin", "login")
				.queryParam("username", "singhrab")
				.queryParam("password", "test123")
				.when()
					.get(uri+"/{userlogin}")
				.then()
					.statusCode(200)
				.body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",containsString("logged in user session"))
				 .log().all();
					
					
				
			}
			
			
			@Test(priority=16)
			public void deleteUser(){
				String uri="https://petstore.swagger.io/v2/user";
				given()
					
				.pathParam("username", "singhrab")
				.when()
					.delete(uri+"/{username}")
				.then()
					.statusCode(200)
				.body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",equalTo("singhrab"))
				 .log().all();
					
					
				
			}

			@Test(priority=17)
			public void logout(){
				String uri="https://petstore.swagger.io/v2/user/logout";
				given()
					
				
				.when()
					.get(uri)
				.then()
					.statusCode(200)
				.body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",containsString("ok"))
				 .log().all();
					
					
				
			}
			@Test(priority=18)
			public void createUser() throws FileNotFoundException{
				
				File file = new File(".\\src\\test\\resources\\jsonFile\\updateUserput.json");
				FileReader fr= new FileReader(file);
				JSONTokener jt=new JSONTokener(fr);
				JSONObject  data=new JSONObject (jt);
				
				given()
				 .contentType("application/json")
				 .body(data.toString())
				.when()
				 .post("https://petstore.swagger.io/v2/user")
				.then()
				 .statusCode(200)
				 .body("code",equalTo(200))
				 .body("type",equalTo("unknown"))
				 .body("message",equalTo("112"))
				 .header("Content-Type","application/json")
				 .log().all();
			}
			

			
			
}
