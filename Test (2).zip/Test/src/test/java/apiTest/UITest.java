package apiTest;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
public class UITest {
public String baseUrl = "https://www.jaguarlandrover.com/";
String driverPath = ".\\src\\test\\resources\\driver\\chromedriver.exe";
public WebDriver driver ;
@BeforeClass
public void launchBrowser() {
System.out.println("launching Chrome browser");
System.setProperty("webdriver.chrome.driver", driverPath);
driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get(baseUrl);

}

@Test(priority = 1)
public void verifyHomepageTitle() {
String expectedTitle = "JLR Corporate Website";
String actualTitle = driver.getTitle();
Assert.assertEquals(actualTitle, expectedTitle);
}

@Test(priority = 2)
public void voidMouseHoverAtComapnyAndClickOnLeadership() throws InterruptedException{
WebElement JLRlogo=driver.findElement(By.xpath("//img[@src='/themes/custom/jlr_corporate_2024/images/logos/logo-black.svg']"));
JLRlogo.click();
WebElement company=driver.findElement(By.xpath("(//div[normalize-space()='Company'])[4]"));
Actions action=new Actions(driver);
action.moveToElement(company);
action.click().build().perform();
WebElement leadership=driver.findElement(By.xpath("(//a[text()='Leadership'])[2]"));
leadership.click();
WebElement execcutiveTeam=driver.findElement(By.xpath("//button[text()='EXECUTIVE TEAM']"));
 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", execcutiveTeam);
 execcutiveTeam.isDisplayed();
 execcutiveTeam.click();
 

}

@Test(priority = 3)
public void goToCareer(){
WebElement JLRlogo=driver.findElement(By.xpath("//img[@src='/themes/custom/jlr_corporate_2024/images/logos/logo-black.svg']"));
JLRlogo.isDisplayed();
JLRlogo.click();
WebElement people=driver.findElement(By.xpath("(//div[normalize-space()='People'])[4]"));
Actions action=new Actions(driver);
action.moveToElement(people);
action.click().build().perform();
WebElement careers=driver.findElement(By.xpath("(//a[text()='Careers'])[2]"));
careers.isDisplayed();
careers.click();
WebElement findJob=driver.findElement(By.xpath("//a[text()='FIND A JOB']"));
findJob.isDisplayed();
action.moveToElement(findJob);
action.click().build().perform();
driver.findElement(By.xpath("//a[text()='Search jobs']")).click();
driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Automation tester");
driver.findElement(By.id("searchresults")).isDisplayed();

}

@Test(priority = 4)
public void validateAllBrands(){

driver.navigate().to("https://www.jaguarlandrover.com/");
WebElement brands=driver.findElement(By.xpath("(//div[normalize-space()='Brands'])[4]"));
Actions Actions=new Actions(driver);
Actions.moveToElement(brands).perform();
List<String> list=Arrays.asList("Our Brands","Range Rover","Defender","Discovery","Jaguar");
try {
            List<WebElement> listOfBrand = driver.findElements(By.xpath("(//a[text()='Our Brands'])[2]/parent::div"));

            for(WebElement brand: listOfBrand){
            	String brandName=brand.getText();
				if(list.contains(brandName))
                System.out.println("Brand Exist");
            }

        } catch (NoSuchElementException e) {}
        System.out.println("Exception Exist");
    }  


@Test(priority = 5)
public void goToCodeOfConduct(){

WebElement JLRlogo=driver.findElement(By.xpath("//img[@src='/themes/custom/jlr_corporate_2024/images/logos/logo-black.svg']"));
JLRlogo.click();
WebElement codeOfConduct=driver.findElement(By.xpath("//a[text()='Code of Conduct']"));
 ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", codeOfConduct);
 WebDriverWait wait=new WebDriverWait(driver, 5);
 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Code of Conduct']")));
 codeOfConduct.click();
 String expectedTitle = "Code of Conduct";
String actualTitle = driver.getTitle();
Assert.assertTrue(actualTitle.contains(expectedTitle));
}
@AfterClass
public void terminateBrowser(){
driver.close();
driver.quit();
}
}